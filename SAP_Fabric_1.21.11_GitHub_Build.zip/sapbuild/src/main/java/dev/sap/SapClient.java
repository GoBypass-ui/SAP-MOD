package dev.sap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.player.Player;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class SapClient implements ClientModInitializer {
    private static final String KEY_CATEGORY = "key.categories.sap";
    private static KeyMapping toggleKey;
    private static boolean enabled = false;
    private static final Map<UUID, Boolean> previousGlow = new HashMap<>();

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.sap.toggle_glow",
                GLFW.GLFW_KEY_K,
                KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.displayClientMessage(
                            Component.literal(enabled ? "PLAYER GLOW: ON" : "PLAYER GLOW: OFF")
                                    .withStyle(enabled ? ChatFormatting.GREEN : ChatFormatting.RED),
                            true
                    );
                }
                if (!enabled) {
                    restorePlayers();
                }
            }

            if (enabled && client.level != null && client.player != null) {
                for (Player player : client.level.players()) {
                    if (player == client.player) continue;
                    previousGlow.putIfAbsent(player.getUUID(), player.isCurrentlyGlowing());
                    player.setGlowingTag(true);
                }
            }

        });
    }

    private static void restorePlayers() {
        Minecraft client = Minecraft.getInstance();
        if (client.level != null) {
            for (Player player : client.level.players()) {
                Boolean wasGlowing = previousGlow.get(player.getUUID());
                if (wasGlowing != null) {
                    player.setGlowingTag(wasGlowing);
                }
            }
        }
        previousGlow.clear();
    }
}
